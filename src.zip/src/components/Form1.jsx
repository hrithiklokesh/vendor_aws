import React, { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { VendorContext } from "../context/VendorContext";
import { UserContext } from "../context/UserContext";
import "../Styles/Form1.css";

function Form1() {
  const navigate = useNavigate();
  const vendorContext = useContext(VendorContext);
  const { vendorData, setVendorData, currentUser: vendorContextUser } = vendorContext;
  const { currentUser: userContextUser } = useContext(UserContext) || {};
  
  // Use either context's user
  const currentUser = vendorContextUser || userContextUser;

  // Initialize state for form fields
  const [formData, setFormData] = useState({
    companyName: vendorData.vendorDetails.companyName || "",
    primaryContactName: vendorData.vendorDetails.primaryContactName || currentUser?.name || "",
    designation: vendorData.vendorDetails.designation || "",
    phoneNumber: vendorData.vendorDetails.phoneNumber || "",
    primaryContactEmail: vendorData.vendorDetails.primaryContactEmail || currentUser?.email || "",
    address: vendorData.vendorDetails.address || "",
    city: vendorData.vendorDetails.city || "",
    state: vendorData.vendorDetails.state || "",
    pinCode: vendorData.vendorDetails.pinCode || "",
    gstin: vendorData.vendorDetails.gstin || "",
  });

  // State to control the visibility of the "Save Changes" indicator
  const [showSaveIndicator, setShowSaveIndicator] = useState(false);

  // Load saved data from localStorage when component mounts
  useEffect(() => {
    if (currentUser) {
      const userKey = `user-${currentUser.id}-form1Data`;
      const savedData = localStorage.getItem(userKey);
      if (savedData) {
        setFormData(JSON.parse(savedData));
      }
    }
  }, [currentUser]);

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleNext = () => {
    setVendorData(prev => ({
      ...prev,
      vendorDetails: {
        companyName: formData.companyName,
        primaryContactName: formData.primaryContactName,
        designation: formData.designation,
        phoneNumber: formData.phoneNumber,
        primaryContactEmail: formData.primaryContactEmail,
        address: formData.address,
        city: formData.city,
        state: formData.state,
        pinCode: formData.pinCode,
        gstin: formData.gstin
      }
    }));
    navigate("/Form2"); // Navigate to Form2
  };

  // New onSubmit handler for form validation
  const handleSubmit = (e) => {
    e.preventDefault();
    // Check for empty required fields
    const requiredFields = [
      "companyName",
      "primaryContactName",
      "designation",
      "phoneNumber",
      "address",
      "email",
      "city",
      "state",
      "pinCode",
      "gstin"
    ];
    for (const field of requiredFields) {
      if (!formData[field] || formData[field].trim() === "") {
        alert("Please fill the field: " + field);
        return;
      }
    }
    // If all fields are filled, proceed
    handleNext();
  };

  return (
    <div className="f1-kyc-1-main-container">
      {/* Left Section (Sidebar) */}
      <div className="f1-wrapper">
        <span className="f1-text">CG</span>
        <span className="f1-text-2">Complete your KYC</span>
        <span className="f1-text-3">
          Please complete your KYC verification by submitting the required
          documents to ensure seamless access to our services
        </span>
        <div className="f1-section">
          <div className="img" />
          <span className="f1-text-4">Vendor Details</span>
        </div>
        <span className="f1-text-5">Please provide vendor details</span>
        <div className="box">
          <div className="f1-img-2" />
          <span className="f1-text-6">Company details</span>
        </div>
        <span className="f1-text-7">Please provide your company details</span>
        <div className="section-2">
          <div className="check-fill" />
          <span className="service-product-offered">Service/product offered</span>
        </div>
        <span className="provide-details-service">
          Please provide details about your service
        </span>
        <div className="flex-row-a">
          <div className="check-fill-1" />
          <span className="f1-bank-details">Bank details</span>
        </div>
        <span className="f1-provide-bank-details">Please provide Bank details</span>
        <div className="flex-row-ecd">
          <div className="check-fill-2" />
          <span className="f1-compliance-certifications">
            Compliance and certifications
          </span>
        </div>
        <span className="f1-provide-certifications">
          Please provide certifications
        </span>
        <div className="flex-row-ca">
          <div className="check-fill-3" />
          <span className="f1-additional-details">Additional details</span>
        </div>
        <span className="f1-text-f">Please provide Additional details</span>
      </div>

      {/* Right Section (Form) */}
      <div className="f1-form-section">
        <span className="f1-text-10">Vendor Details</span>
        <span className="f1-text-12">
          Provide your vendor details for verification and onboarding.
        </span>

        <form onSubmit={handleSubmit}>
          {/* Vendor Name */}
          <div className="f1-wrapper-4">
            <input
              required
              type="text"
              className="f1-text-13"
              placeholder="Company name"
              name="companyName"
              value={formData.companyName}
              onChange={handleInputChange}
            />
          </div>
          <span className="f1-text-14">Vendor name</span>
          <div className="f1-pic-3" />

          {/* Primary Contact Name */}
          <div className="f1-section-3">
            <input
              required
              type="text"
              className="f1-text-15"
              placeholder="Name"
              name="primaryContactName"
              value={formData.primaryContactName}
              onChange={handleInputChange}
            />
          </div>
          <span className="f1-text-16">*</span>
          <span className="f1-text-17">Primary contact name</span>

          <div className="f1-wrapper-5">
            <input
              required
              type="text"
              className="f1-text-18"
              placeholder="Designation"
              name="designation"
              value={formData.designation}
              onChange={handleInputChange}
            />
          </div>
          <div className="f1-pic-4" />

          {/* Contact Details */}
          <div className="f1-wrapper-6">
            <input
              required
              type="text"
              className="f1-text-19"
              placeholder="Phone number"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleInputChange}
            />
          </div>
          <span className="f1-text-1a">*</span>
          <span className="f1-text-1b">Contact Details</span>

          <div className="f1-group-2">
            <input
              required
              type="email"
              className="f1-text-1c"
              placeholder="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
            />
          </div>
          <div className="f1-pic-5" />
          <span className="f1-text-1d">*</span>

          {/* Address */}
          <div className="f1-wrapper-7">
            <input
              required
              type="text"
              className="f1-text-1e"
              placeholder="Address"
              name="address"
              value={formData.address}
              onChange={handleInputChange}
            />
          </div>
          <span className="f1-text-1f">Address</span>

          <div className="f1-section-5">
            <input
              required
              type="text"
              className="f1-text-21"
              placeholder="City"
              name="city"
              value={formData.city}
              onChange={handleInputChange}
            />
          </div>

          <div className="f1-section-4">
            <input
              required
              type="text"
              className="f1-text-20"
              placeholder="State"
              name="state"
              value={formData.state}
              onChange={handleInputChange}
            />
          </div>

          <div className="f1-section-6">
            <input
              required
              type="text"
              className="f1-text-22"
              placeholder="Pin code"
              name="pinCode"
              value={formData.pinCode}
              onChange={handleInputChange}
            />
          </div>
          <div className="f1-img-6" />

          {/* Business Registration Number */}
          <div className="f1-wrapper-8">
            <input
              required
              type="text"
              className="f1-text-23"
              placeholder="GSTIN/Registration number"
              name="gstin"
              value={formData.gstin}
              onChange={handleInputChange}
            />
          </div>
          <span className="f1-text-24">*</span>
          <span className="f1-text-25">Business registration number</span>

          {/* Buttons */}
          <button type="submit" className="f1-pic-6">
            <span className="f1-text-26">Next</span>
          </button>
        </form>

        <div className="f1-bottom-spacer" />
      </div>
    </div>
  );
}

export default Form1;
