import React, { useState, useEffect, useContext } from "react";
import { VendorContext } from "../context/VendorContext";
import { UserContext } from "../context/UserContext";
import { useNavigate } from "react-router-dom";
import "../Styles/Form4.css";
import "../Styles/Form1.css";

export default function Form4() {
  const navigate = useNavigate();
  const { vendorData, setVendorData } = useContext(VendorContext);
  const { currentUser } = useContext(UserContext) || {};
      
  const [formData, setFormData] = useState({
    bankName: vendorData.bankDetails.bankName || "",
    accountName: vendorData.bankDetails.accountName || "",
    accountNumber: vendorData.bankDetails.accountNumber || "",
    ifscCode: vendorData.bankDetails.ifscCode || "",
    branchAddress: vendorData.bankDetails.branchAddress || "",
  });

  // State to control the visibility of the "Save Changes" indicator
  const [showSaveIndicator, setShowSaveIndicator] = useState(false);

  // Load saved data from localStorage on mount
  useEffect(() => {
    if (currentUser) {
      const savedData = localStorage.getItem(`form4Data_${currentUser.id}`);
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        setFormData(parsedData);
        setVendorData(prev => ({
          ...prev,
          bankDetails: parsedData
        }));
      }
    }
  }, [currentUser]);

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handlePrevious = () => {
    navigate("/Form3");
  };

  const handleNext = () => {
    if (currentUser) {
      localStorage.setItem(`form4Data_${currentUser.id}`, JSON.stringify(formData));
    }
    setVendorData(prev => ({
      ...prev,
      bankDetails: {
        bankName: formData.bankName,
        accountName: formData.accountName,
        accountNumber: formData.accountNumber,
        ifscCode: formData.ifscCode,
        branchAddress: formData.branchAddress,
      }
    }));
    navigate("/Form5");
  };

  // New onSubmit handler for form validation
  const handleSubmit = (e) => {
    e.preventDefault();
    const requiredFields = [
      "bankName",
      "accountName",
      "accountNumber",
      "ifscCode",
      "branchAddress"
    ];
    for (const field of requiredFields) {
      if (!formData[field] || formData[field].trim() === "") {
        alert("Please fill the field: " + field);
        return;
      }
    }
    handleNext();
  };

  return (
    <div className="main-container">

      {/* Sidebar */}
      <div className="f4-wrapper">
        <span className="f1-text">CG</span>
        <span className="f1-text-2">Complete your KYC</span>
        <span className="f1-text-3">
          Please complete your KYC verification by submitting the required
          documents to ensure seamless access to our services
        </span>
        <div className="f4-section">
          <div className="img" />
          <span className="f1-text-4">Vendor Details</span>
        </div>
        <span className="f1-text-5">Please provide vendor details</span>
        <div className="box">
          <div className="img" />
          <span className="f4-text-6">Company details</span>
        </div>
        <span className="f4-text-7">Please provide your company details</span>
        <div className="section-2">
          <div className="f3-img" />
          <span className="f4-service-product-offered">Service/product offered</span>
        </div>
        <span className="f4-provide-details-service">
          Please provide details about your service
        </span>
        <div className="flex-row-a">
          <div className="img" />
          <span className="form4-bank-details">Bank details</span>
        </div>
        <span className="form4-provide-bank-details">Please provide Bank details</span>
        <div className="flex-row-ecd">
          <div className="check-fill-2" />
          <span className="f4-compliance-certifications">
            Compliance and certifications
          </span>
        </div>
        <span className="f4-provide-certifications">
          Please provide certifications
        </span>
        <div className="flex-row-ca">
          <div className="check-fill-3" />
          <span className="f4-additional-details">Additional details</span>
        </div>
        <span className="f4-text-f">Please provide Additional details</span>
      </div>

      {/* Form Section */}
      <form onSubmit={handleSubmit}>
        <span className="text-10">Bank details</span>
        <span className="text-12">
          Provide your bank details for verification and onboarding.
        </span>

        {/* Bank Name */}
        <div className="box-2">
          <input
            type="text"
            className="text-13"
            placeholder="Bank Name"
            required
            name="bankName"
            value={formData.bankName}
            onChange={handleInputChange}
            style={{
              position: "relative",
              width: "70%",
              border: "none",
              background: "transparent",
              fontFamily: "Poppins, var(--default-font-family)",
              fontSize: "18px",
              fontWeight: "500",
              color: "#555555",
              opacity: "0.5",
              paddingLeft: "15px",
              lineHeight: "58px",
              textAlign: "left",
            }}
          />
        </div>
        <span className="text-14">Bank name</span>
        <div className="img-4" />

        {/* Account Name */}
        <div className="box-3">
          <input
            type="text"
            className="text-15"
            placeholder="Account Name"
            required
            name="accountName"
            value={formData.accountName}
            onChange={handleInputChange}
            style={{
              position: "relative",
              width: "70%",
              border: "none",
              background: "transparent",
              fontFamily: "Poppins, var(--default-font-family)",
              fontSize: "18px",
              fontWeight: "500",
              color: "#555555",
              opacity: "0.5",
              paddingLeft: "15px",
              lineHeight: "58px",
              textAlign: "left",
            }}
          />
        </div>
        <span className="text-16">Account name</span>
        <div className="pic-5" />

        {/* Account Number */}
        <div className="section-3">
          <input
            type="text"
            className="text-17"
            placeholder="Account Number"
            required
            name="accountNumber"
            value={formData.accountNumber}
            onChange={handleInputChange}
            style={{
              position: "relative",
              width: "70%",
              border: "none",
              background: "transparent",
              fontFamily: "Poppins, var(--default-font-family)",
              fontSize: "18px",
              fontWeight: "500",
              color: "#555555",
              opacity: "0.5",
              paddingLeft: "15px",
              lineHeight: "58px",
              textAlign: "left",
            }}
          />
        </div>
        <span className="f4-text-18">Account number</span>
        <div className="img-5" />

        {/* IFSC Code */}
        <div className="section-4">
          <input
            type="text"
            className="text-19"
            placeholder="IFSC Code"
            required
            name="ifscCode"
            value={formData.ifscCode}
            onChange={handleInputChange}
            style={{
              position: "relative",
              width: "70%",
              border: "none",
              background: "transparent",
              fontFamily: "Poppins, var(--default-font-family)",
              fontSize: "18px",
              fontWeight: "500",
              color: "#555555",
              opacity: "0.5",
              paddingLeft: "15px",
              lineHeight: "58px",
              textAlign: "left",
            }}
          />
        </div>
        <span className="text-1a">IFSC Code</span>

        {/* Branch Address */}
        <div className="f4-rectangle">
          <input
            type="text"
            className="branch-address"
            placeholder="Branch Address"
            required
            name="branchAddress"
            value={formData.branchAddress}
            onChange={handleInputChange}
            style={{
              position: "relative",
              width: "70%",
              border: "none",
              background: "transparent",
              fontFamily: "Poppins, var(--default-font-family)",
              fontSize: "18px",
              fontWeight: "500",
              color: "#555555",
              opacity: "0.5",
              padding: "10px",
              lineHeight: "38px",
              resize: "none",
              textAlign: "left",
            }}
          />
        </div>
        <span className="branch-address-1">Branch address</span>

        {/* Buttons */}
        <button type="submit" className="f4-rectangle-2">
          <span className="next">Next</span>
        </button>
        <div className="f4-rectangle-3" onClick={handlePrevious}>
          <span className="f4-save">Previous</span>
        </div>
      </form>
    </div>
  );
}
