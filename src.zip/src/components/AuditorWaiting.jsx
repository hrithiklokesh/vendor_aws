
import React from "react";
import "../Styles/Auditor.css";

export default function Auditor() {
  return (
    <div className="a-main-container">
      <div className="a-box">
        <span className="a-text">Great work</span>
        <span className="a-text-2"> .You are almost there!!</span>
      </div>
      <span className="a-text-3">
        Thank you for submitting your KYC details. Our team is currently
        reviewing your documents to ensure compliance and security.
      </span>
      <span className="a-text-4">What happens next?</span>
      <div className="a-flex-row-cac">
        <div className="a-rectangle">
          <div className="a-qlementine-icons-preview" />
        </div>
        <div className="a-rectangle-1">
          <div className="a-mdi-clock-outline" />
        </div>
        <div className="a-rectangle-2">
          <div className="a-mdi-approve" />
        </div>
        <div className="a-rectangle-3" /> {/* No need for animate class */}
        <div className="a-rectangle-4" />
      </div>
      <div className="a-flex-row-d">
        <span className="a-review-process">Review process</span>
        <span className="a-processing-time">Processing time</span>
        <span className="a-approval-rejection">Approval or Rejection</span>
      </div>
      <div className="a-flex-row-aa">
        <span className="a-verification-team">
          Our verification team will manually check your submitted documents.
        </span>
        <span className="a-verification-process">
          This process typically takes 5-7 working days.
        </span>
        <span className="a-approval-notification">
          If approved, you can proceed to the next steps. If any issues arise,
          we’ll notify you via email.
        </span>
      </div>
      <span className="a-need-assistance">Need Assistance?</span>
      <div className="a-contact-support-team">
        <span className="a-contact-support-team-5">
          If you have any questions, please contact our support team at{" "}
        </span>
        <span className="a-support-email">Corporate@caasdiglobal.com</span>
        <span className="a-contact-support-team-6">
          {" "}
          or visit our Help Center
        </span>
      </div>
    </div>
  );
}