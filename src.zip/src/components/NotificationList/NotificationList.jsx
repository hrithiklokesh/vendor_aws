import React, { useState, useRef, useEffect } from "react";
import { Link } from 'react-router-dom'; // Import Link
import NotificationItem from "./NotificationItem";
import { ArrowPathIcon } from '@heroicons/react/24/solid'; // For loading indicator

// --- Define API Base URL ---
// TODO: Move this to a .env file for frontend builds
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5001';

export default function NotificationList() {
  // Remove initialNotifications
  // const initialNotifications = [ ... ];

  // --- State Management ---
  const [allNotifications, setAllNotifications] = useState([]); // Holds all fetched notifications
  const [filteredNotifications, setFilteredNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  // --- End State Management ---

  const [activeFilter, setActiveFilter] = useState('all');
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);
  const filterRef = useRef(null); // Ref for the filter dropdown container

  // --- Fetch Notifications ---
  useEffect(() => {
    const fetchNotifications = async () => {
      setIsLoading(true);
      setError(null);
      setAllNotifications([]);
      setFilteredNotifications([]);

      try {
        const response = await fetch(`${API_BASE_URL}/api/project-leads/notifications`);
        if (!response.ok) {
          let errorMsg = `HTTP error! status: ${response.status}`;
          try {
            const errData = await response.json();
            errorMsg = errData.message || errData.error || errorMsg;
          } catch (_) { /* Ignore if response body isn't JSON */ }
          throw new Error(errorMsg);
        }
        const data = await response.json();

        // --- Map Lead Data to Notification Structure ---
        const formattedNotifications = data.map(lead => {
          // Determine notification type (using badge text as indicator for now)
          const notificationType = "New Lead"; // Explicitly set for leads fetched from this endpoint
          let notificationLink = null; // Default link to null (non-clickable)

          // Set link ONLY if it's a lead notification
          if (notificationType === "New Lead") {
            notificationLink = '/leads';
          }
          // Example for future:
          // else if (notificationType === "New Message") {
          //   notificationLink = `/messages/${message.id}`;
          // }

          return {
            id: lead.leadId,
            title: `New Lead: ${lead.name || 'Unnamed Lead'}`,
            message: lead.description || `Review required for lead from client: ${lead.clientId || 'N/A'}.`,
            time: lead.createdAt ? new Date(lead.createdAt).toLocaleDateString() : 'Recently',
            sender: `Client ID: ${lead.clientId || 'N/A'}`,
            avatar: 'https://via.placeholder.com/40/CBD5E0/4A5568?text=N',
            icon: 'https://codia-f2c.s3.us-west-1.amazonaws.com/image/2025-04-25/h0Lwu0EJrH.png',
            badge: { text: notificationType, color: "#fefcbf" }, // Use the type here
            isImportant: true,
            isSaved: false,
            isRead: false,
            link: notificationLink, // Use the conditionally set link
            // We could also add an explicit 'type' field if needed later:
            // type: 'lead',
          };
        });
        // --- End Mapping ---

        setAllNotifications(formattedNotifications);
        applyFilter('all', formattedNotifications);

      } catch (e) {
        console.error("Failed to fetch notifications:", e);
        setError(e.message || 'Failed to load notifications.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchNotifications();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // Fetch on mount

  // --- Actions (operate on local state for now) ---
  const clearAllNotifications = () => {
    // TODO: Add API call later if needed to persist cleared state
    setAllNotifications([]);
    setFilteredNotifications([]);
  };
  
  const deleteNotification = (id) => {
    // TODO: Add API call later
    const updatedNotifications = allNotifications.filter(notification => notification.id !== id);
    setAllNotifications(updatedNotifications);
    applyFilter(activeFilter, updatedNotifications); // Re-apply filter
  };

  const markAsImportant = (id) => {
    // TODO: Add API call later
    const updatedNotifications = allNotifications.map(notification =>
      notification.id === id 
        ? { ...notification, isImportant: !notification.isImportant }
        : notification
    );
    setAllNotifications(updatedNotifications);
    applyFilter(activeFilter, updatedNotifications); // Re-apply filter
  };
  
  const saveNotification = (id) => {
    // TODO: Add API call later
    const updatedNotifications = allNotifications.map(notification =>
      notification.id === id 
        ? { ...notification, isSaved: !notification.isSaved }
        : notification
    );
    setAllNotifications(updatedNotifications);
    applyFilter(activeFilter, updatedNotifications); // Re-apply filter
  };

   const markAsRead = (id) => {
      // TODO: Add API call later
      const updatedNotifications = allNotifications.map(notification =>
        notification.id === id ? { ...notification, isRead: true } : notification
      );
      setAllNotifications(updatedNotifications);
      applyFilter(activeFilter, updatedNotifications); // Re-apply filter
   };


  // --- Filtering ---
  // Function now takes the list to filter as an argument
  const applyFilter = (filterType, notifList = allNotifications) => {
    setActiveFilter(filterType);
    setShowFilterDropdown(false); // Close dropdown after selection
    
    let result = [];
    switch(filterType) {
      case 'unread':
        result = notifList.filter(notification => !notification.isRead);
        break;
      case 'important':
        result = notifList.filter(notification => notification.isImportant);
        break;
      case 'saved':
        result = notifList.filter(notification => notification.isSaved);
        break;
      // Keep client/pm filters for now, though they might not apply to lead notifications
      case 'client':
         result = notifList.filter(notification =>
             notification.badge && notification.badge.text.toLowerCase().includes('client') // More flexible check
         );
        break;
      case 'pm':
         result = notifList.filter(notification =>
             notification.badge && notification.badge.text.toLowerCase().includes('manager')
         );
         break;
      case 'lead': // Add a specific filter for leads if needed
         result = notifList.filter(notification =>
              notification.badge && notification.badge.text.toLowerCase() === 'lead'
          );
        break;
      case 'all':
      default:
        result = [...notifList]; // Return a copy
    }
    setFilteredNotifications(result);
  };

  // Effect to close dropdown on outside click (no changes needed)
  useEffect(() => {
    function handleClickOutside(event) {
       const toggleButton = filterRef.current?.querySelector('button');
       if (filterRef.current && !filterRef.current.contains(event.target) && toggleButton && !toggleButton.contains(event.target)) {
        setShowFilterDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [filterRef]);

  // Calculate unread count based on the current master list
  const unreadCount = allNotifications.filter(n => !n.isRead).length;

  // Filter labels mapping for display
   const filterLabels = {
    all: 'All notifications',
    unread: 'Unread',
    important: 'Important',
    saved: 'Saved',
    lead: 'Leads', // Added Lead filter option
    client: 'From Client', // Keep or remove based on future notification types
    pm: 'From PM', // Keep or remove based on future notification types
  };
  const currentFilterLabel = filterLabels[activeFilter] || 'Filter';

  // --- Render Loading State ---
   if (isLoading) {
        return (
            <div className="p-10 text-center text-gray-500 flex items-center justify-center gap-2">
                 <ArrowPathIcon className="h-5 w-5 animate-spin"/> Loading notifications...
            </div>
        );
   }

   // --- Render Error State ---
    if (error) {
        return (
            <div className="p-6 bg-red-50 border border-red-200 rounded-lg text-center">
                <h3 className="text-lg font-semibold text-red-700 mb-2">Error Loading Notifications</h3>
                <p className="text-red-600 mb-4">{error}</p>
                {/* Optional: Add a retry button */}
                {/* <button onClick={fetchNotifications} className="...">Retry</button> */}
            </div>
        );
    }


  return (
    <section className="bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Header */}
      <div className="p-4 md:p-6 border-b border-gray-200">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Left Side: Count */}
          <div>
            <p className="font-['Poppins'] text-sm md:text-[15px] text-gray-600">
               {allNotifications.length === filteredNotifications.length
                ? `${allNotifications.length} total notification${allNotifications.length !== 1 ? 's' : ''}`
                : `${filteredNotifications.length} matching notification${filteredNotifications.length !== 1 ? 's' : ''}`
               }
               {` (${unreadCount} unread)`}
            </p>
          </div>
          
          {/* Right Side: Buttons */}
          <div className="flex items-center space-x-3">
             {/* Filter Button & Dropdown */}
            <div className="relative" ref={filterRef}>
              <button 
                className="flex items-center bg-[#eff2f2] rounded px-3 py-1.5 text-sm hover:bg-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-emerald-500"
                onClick={() => setShowFilterDropdown(!showFilterDropdown)}
                aria-haspopup="true"
                aria-expanded={showFilterDropdown}
              >
                {/* Filter Icon */}
                <div className="w-5 h-5 bg-[url(https://codia-f2c.s3.us-west-1.amazonaws.com/image/2025-04-25/YP70cvFxNj.png)] bg-cover bg-no-repeat mr-2"></div>
                <span className="font-['Poppins'] text-sm font-medium text-gray-800">
                  {currentFilterLabel}
                </span>
                 {/* Chevron Icon */}
                <div className="w-5 h-5 bg-[url(https://codia-f2c.s3.us-west-1.amazonaws.com/image/2025-04-25/qJNGM92kR3.png)] bg-cover bg-no-repeat ml-2"></div>
              </button>
              
              {/* Filter Dropdown Panel */}
              {showFilterDropdown && (
                <div className="absolute right-0 md:left-0 top-full mt-1 z-20">
                   <div className="w-[196px] bg-white rounded-[8px] border border-solid border-[rgba(17,17,17,0.1)] relative shadow-[0_4px_3.5px_0_rgba(0,0,0,0.1)] overflow-hidden">
                    <ul className="py-1">
                       {Object.entries(filterLabels).map(([key, label]) => (
                        <li key={key} className={key !== 'all' ? "border-t border-gray-100" : ""}>
                        <button 
                               className={`w-full text-left px-4 py-1.5 hover:bg-gray-100 font-["Poppins"] text-sm ${activeFilter === key ? 'bg-gray-100 font-semibold' : 'font-normal text-gray-700'}`}
                               onClick={() => applyFilter(key)} // Apply filter using the current list
                               role="menuitem"
                        >
                              {label}
                        </button>
                      </li>
                       ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
            
            {/* Clear All Button */}
            {allNotifications.length > 0 && ( // Condition on allNotifications
            <button 
                className="flex items-center bg-[#eff2f2] rounded px-3 py-1.5 text-sm hover:bg-gray-200 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-red-500 disabled:opacity-50"
              onClick={clearAllNotifications}
                disabled={allNotifications.length === 0}
                title="Clear all notifications"
            >
                 {/* Clear Icon */}
              <div className="w-5 h-5 bg-[url(https://codia-f2c.s3.us-west-1.amazonaws.com/image/2025-04-25/W0XSBhnidu.png)] bg-cover bg-no-repeat mr-2"></div>
                <span className="font-['Poppins'] text-sm font-medium text-gray-800">clear all</span>
            </button>
            )}
          </div>
          </div>
        </div>
        
      {/* List Container */}
      <div className="notification-list-container">
          {filteredNotifications.length > 0 ? (
            <ul className="divide-y divide-gray-200">
              {filteredNotifications.map((notification) => (
              // Use NotificationItem - make sure it accepts the 'link' prop
                <NotificationItem 
                  key={notification.id} 
                  notification={notification} 
                  onDelete={deleteNotification}
                  onMarkImportant={markAsImportant}
                  onSave={saveNotification}
                // Pass markAsRead if clicking the item itself should mark read
                // onMarkRead={markAsRead}
                />
              ))}
            </ul>
          ) : (
          // Empty State
          <div className="py-12 px-6 text-center">
            <p className="font-['Poppins'] text-sm text-gray-500">
              {allNotifications.length > 0 // Check if there were notifications initially
                ? `No notifications match the "${currentFilterLabel.toLowerCase()}" filter.`
                : 'You have no notifications yet.'}
              </p>
            </div>
          )}
      </div>
    </section>
  );
}
