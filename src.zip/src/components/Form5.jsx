import React, { useState, useEffect, useContext } from "react";
import { VendorContext } from "../context/VendorContext";
import { UserContext } from "../context/UserContext";
import { useNavigate } from "react-router-dom";
import { uploadFileToS3, deleteFileFromS3 } from "../utils/fileUpload";
import "../Styles/Form5.css";
import "../Styles/Form1.css";
import "../Styles/Form4.css";
import "../styles/Form2.css";

export default function Form5() {
  const navigate = useNavigate();
  const { vendorData, setVendorData } = useContext(VendorContext);
  const { currentUser } = useContext(UserContext) || {};

  const [formData, setFormData] = useState({
    hasCertifications: vendorData.complianceCertifications.hasCertifications || false,
    uploadDocument: vendorData.complianceCertifications.uploadDocument || null,
    isoCertificate: vendorData.complianceCertifications.isoCertificate || null,
    healthSafetyStandards: vendorData.complianceCertifications.healthSafetyStandards || "",
  });

  // State to control the visibility of the "Save Changes" indicator
  const [showSaveIndicator, setShowSaveIndicator] = useState(false);

  // Load saved data from localStorage on mount
  useEffect(() => {
    if (currentUser) {
      const savedData = localStorage.getItem(`form5Data_${currentUser.id}`);
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        setFormData(parsedData);
        setVendorData(prev => ({
          ...prev,
          complianceCertifications: parsedData
        }));
      }
    }
  }, [currentUser]);

  // Handle input changes
  const handleInputChange = async (e) => {
    const { name, value, files } = e.target;
    if (name === "hasCertifications") {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value === "yes",
      }));
    } else if (files) {
      // Store the file in local state first for UI feedback
      setFormData((prevData) => ({
        ...prevData,
        [name]: {
          file: files[0],
          name: files[0].name,
          uploading: true
        },
      }));
      
      try {
        // Only upload to S3 if we have the user's email
        if (currentUser && currentUser.email) {
          // Upload the file to S3
          const section = 'complianceCertifications';
          console.log('Uploading file to S3:', {
            fileName: files[0].name,
            email: currentUser.email,
            documentType: name,
            section: section
          });
          const response = await uploadFileToS3(files[0], currentUser.email, name, section);
          
          console.log('S3 upload response:', {
            success: response.success,
            message: response.message,
            url: response.data?.url,
            documentType: response.data?.documentType,
            section: response.data?.section
          });
          
          // Update the form data with the S3 URL
          setFormData((prevData) => ({
            ...prevData,
            [name]: {
              file: files[0],
              name: files[0].name,
              url: response.data.url,
              uploading: false
            },
          }));
          
          // Show save indicator
          setShowSaveIndicator(true);
          setTimeout(() => setShowSaveIndicator(false), 3000);
        }
      } catch (error) {
        console.error('Error uploading file:', error);
        console.error('Error details:', {
          message: error.message,
          stack: error.stack,
          name: error.name
        });
        // Revert to previous state if upload fails
        setFormData((prevData) => ({
          ...prevData,
          [name]: null,
        }));
        alert(`Failed to upload file: ${error.message}. Please try again.`);
      }
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
  };
  
  // Handle file deletion
  const handleDeleteFile = async (fieldName) => {
    try {
      // Only delete from S3 if we have the URL and user's email
      if (formData[fieldName]?.url && currentUser && currentUser.email) {
        await deleteFileFromS3(currentUser.email, fieldName, 'complianceCertifications');
      }
      
      // Update local state
      setFormData((prevData) => ({
        ...prevData,
        [fieldName]: null,
      }));
      
      // Show save indicator
      setShowSaveIndicator(true);
      setTimeout(() => setShowSaveIndicator(false), 3000);
    } catch (error) {
      console.error('Error deleting file:', error);
      alert('Failed to delete file. Please try again.');
    }
  };

  const handlePrevious = () => {
    navigate("/Form4");
  };

  const handleNext = () => {
    if (currentUser) {
      localStorage.setItem(`form5Data_${currentUser.id}`, JSON.stringify(formData));
    }
    
    // Ensure we're saving the S3 URLs to the vendor data
    // Also save the file objects for the backend to use
    setVendorData(prev => ({
      ...prev,
      complianceCertifications: {
        hasCertifications: formData.hasCertifications,
        uploadDocument: formData.uploadDocument ? {
          url: formData.uploadDocument.url,
          originalName: formData.uploadDocument.name,
          contentType: formData.uploadDocument.file?.type,
          // Keep the file object for the backend to use
          file: formData.uploadDocument.file
        } : null,
        isoCertificate: formData.isoCertificate ? {
          url: formData.isoCertificate.url,
          originalName: formData.isoCertificate.name,
          contentType: formData.isoCertificate.file?.type,
          // Keep the file object for the backend to use
          file: formData.isoCertificate.file
        } : null,
        healthSafetyStandards: formData.healthSafetyStandards,
      }
    }));
    
    console.log("Form5 data saved to context:", {
      uploadDocument: formData.uploadDocument ? {
        url: formData.uploadDocument.url,
        name: formData.uploadDocument.name,
        hasFile: !!formData.uploadDocument.file
      } : null,
      isoCertificate: formData.isoCertificate ? {
        url: formData.isoCertificate.url,
        name: formData.isoCertificate.name,
        hasFile: !!formData.isoCertificate.file
      } : null
    });
    
    navigate("/Form6");
  };

  // Form validation and submission handler
  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.hasCertifications === null || formData.hasCertifications === undefined) {
      alert("Please specify if you have certifications");
      return;
    }
    
    if (formData.hasCertifications) {
      // Check if document is uploaded and has a URL (meaning it's in S3)
      if (!formData.uploadDocument) {
        alert("Please upload the document");
        return;
      }
      
      if (formData.uploadDocument.uploading) {
        alert("Please wait for the document to finish uploading");
        return;
      }
      
      if (!formData.uploadDocument.url) {
        alert("Document upload failed. Please try again.");
        return;
      }
      
      // Check if ISO certificate is uploaded and has a URL
      if (!formData.isoCertificate) {
        alert("Please upload the ISO certificate");
        return;
      }
      
      if (formData.isoCertificate.uploading) {
        alert("Please wait for the ISO certificate to finish uploading");
        return;
      }
      
      if (!formData.isoCertificate.url) {
        alert("ISO certificate upload failed. Please try again.");
        return;
      }
    }
    
    if (!formData.healthSafetyStandards || formData.healthSafetyStandards.trim() === "") {
      alert("Please fill the health and safety standards");
      return;
    }
    
    handleNext();
  };

  return (
    <div className="main-container">
      {/* Save indicator */}
      {showSaveIndicator && (
        <div className="save-indicator" style={{
          position: 'fixed',
          top: '20px',
          right: '20px',
          background: '#4CAF50',
          color: 'white',
          padding: '10px 20px',
          borderRadius: '4px',
          zIndex: 1000,
          boxShadow: '0 2px 5px rgba(0,0,0,0.2)'
        }}>
          Changes saved successfully!
        </div>
      )}
      
      {/* Inline CSS for placeholder centering and styling */}

      {/* Sidebar */}
      <div className="wrapper">
        <span className="f1-text">CG</span>
        <span className="f1-text-2">Complete your KYC</span>
        <span className="f1-text-3">
          Please complete your KYC verification by submitting the required
          documents to ensure seamless access to our services
        </span>
        <div className="form5-img" />
        <span className="form5-text-4">Vendor Details</span>
        <span className="form5-text-5">Please provide vendor details</span>
        <div className="box">
          <div className="img" />
          <span className="f2-text-6">Company details</span>
        </div>
        <span className="f2-text-7">Please provide your company details</span>
        <div className="section-2">
          <div className="f3-img" />
          <span className="f4-service-product-offered">Service/product offered</span>
        </div>
        <span className="f4-provide-details-service">
          Please provide details about your service
        </span>
        <div className="flex-row-a">
          <div className="img" />
          <span className="form4-bank-details">Bank details</span>
        </div>
        <span className="form4-provide-bank-details">Please provide Bank details</span>
        <div className="flex-row-ecd">
          <div className="img" />
          <span className="form5-compliance-certifications">
            Compliance and certifications
          </span>
        </div>
        <span className="form5-provide-certifications">Please provide certifications</span>
        <div className="flex-row-ca">
          <div className="check-fill-3" />
          <span className="f5-additional-details">Additional details</span>
        </div>
        <span className="f5-text-f">Please provide Additional details</span>
      </div>

      {/* Form Section */}
      <form onSubmit={handleSubmit}>
        <span className="CandC">Compliance and Certifications</span>
        <span className="f5-text-12">
          Provide your certification for verification and onboarding.
        </span>
        <span className="f5-text-13">Do you have necessary certifications/licenses?</span>

        {/* Yes/No Radio Buttons */}
        <div className="f5-radio-group">
          <label>
            <input
              type="radio"
              name="hasCertifications"
              value="yes"
              checked={formData.hasCertifications === true}
              onChange={handleInputChange}
            />
            Yes
          </label>
          <label>
            <input
              type="radio"
              name="hasCertifications"
              value="no"
              checked={formData.hasCertifications === false}
              onChange={handleInputChange}
            />
            No
          </label>
        </div>

        {/* Upload Document */}
        <div className="f5-section" onClick={() => !formData.uploadDocument && document.getElementById("uploadDocument").click()}>
          <div className="f5-box-5" />
          <input
            type="file"
            name="uploadDocument"
            onChange={handleInputChange}
            id="uploadDocument"
            style={{ display: "none" }}
          />
          {formData.uploadDocument ? (
            <div className="file-display">
              <span className="file-name">{formData.uploadDocument.name}</span>
              {formData.uploadDocument.uploading && <span className="upload-status">Uploading...</span>}
              {formData.uploadDocument.url && <span className="upload-status">Uploaded to S3</span>}
              <button 
                className="delete-btn" 
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteFile("uploadDocument");
                }}
                disabled={formData.uploadDocument.uploading}
              >
                Delete
              </button>
            </div>
          ) : (
            <>
              <span className="f5-text-16">Upload document</span>
              <span className="f5-text-17">upload</span>
              <div className="f5-img-7" />
            </>
          )}
        </div>
        <div className="f5-img-8" />

        {/* ISO Certificate */}
        <div className="f5-wrapper-4" onClick={() => !formData.isoCertificate && document.getElementById("isoCertificate").click()}>
          <div className="f5-section-2" />
          <input
            type="file"
            name="isoCertificate"
            onChange={handleInputChange}
            id="isoCertificate"
            style={{ display: "none" }}
          />
          {formData.isoCertificate ? (
            <div className="file-display">
              <span className="file-name">{formData.isoCertificate.name}</span>
              {formData.isoCertificate.uploading && <span className="upload-status">Uploading...</span>}
              {formData.isoCertificate.url && <span className="upload-status">Uploaded to S3</span>}
              <button 
                className="delete-btn" 
                onClick={(e) => {
                  e.stopPropagation();
                  handleDeleteFile("isoCertificate");
                }}
                disabled={formData.isoCertificate.uploading}
              >
                Delete
              </button>
            </div>
          ) : (
            <>
              <span className="f5-text-18">upload</span>
              <span className="f5-text-19">ISO Certificate</span>
              <div className="f5-pic-4" />
            </>
          )}
        </div>
        <span className="f5-text-1a">ISO Certificate</span>
        <div className="f5-img-9" />

        {/* Health and Safety Standards */}
        <div className="f5-group">
          <textarea
            className="f5-text-1b"
            placeholder="Health and safety standards you take"
            name="healthSafetyStandards"
            value={formData.healthSafetyStandards}
            onChange={handleInputChange}
            style={{
              position: "relative",
              width: "100%",
              height: "100%",
              border: "none",
              background: "transparent",
              fontFamily: "Poppins, var(--default-font-family)",
              fontSize: "18px",
              fontWeight: "500",
              color: "#555555",
              opacity: "0.5",
              padding: "10px",
              lineHeight: "38px",
              resize: "none",
              textAlign: "left",
            }}
          />
        </div>
        <span className="f5-text-1c">Health and safety standards</span>

        {/* Buttons */}
        <button type="submit" className="f5-img-a">
          <span className="f5-text-1d">Next</span>
        </button>
        <div className="f5-wrapper-5" onClick={handlePrevious}>
          <span className="f5-text-1e">Previous</span>
        </div>
      </form>
    </div>
  );
}
