import React from "react";

const GlowEffects = () => {
  return (
    <>
      <div className="ellipse top-glow" role="presentation"></div>
      <div className="ellipse-5 bottom-glow" role="presentation"></div>
    </>
  );
};

export default GlowEffects;
