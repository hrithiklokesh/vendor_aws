import { Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import { VendorProvider } from "./context/VendorContext";
import { UserProvider } from "./context/UserContext";
import SignUp from "./components/SignUp";
import Home from "./pages/Home/Home";
import UserProjectPage from './pages/UserProjectPage/UserProjectPage'; // Assuming UserProjectPage is here
import UserPortfolio from './pages/UserProductPage/UserProductPage'; // Assuming UserProductPage is here
import { VendorDashboard } from "./pages/VendorDashboard/VendorDashboard";
import NewAuditorDashboard from "./components/NewAuditorDashboard";
import Form1 from "./components/Form1";
import Form2 from "./components/Form2";
import Form3 from "./components/Form3";
import Form4 from "./components/Form4";
import Form5 from "./components/Form5";
import Form6 from "./components/Form6";
import Auditor from "./components/AuditorWaiting";
import Login from "./components/Login";
import GoogleOAuthCallback from "./components/GoogleOAuthCallback";
import { Header } from "./components/Header/Header";
import { Outlet } from "react-router-dom";
import ProjectsPage from "./pages/ProjectsPage/ProjectsPage"; // Assuming ProjectsPage is here
import LeadDetailPage from "./pages/LeadDetailPage/LeadDetailPage"; // Assuming LeadDetailPage is here
import LeadsPage from "./pages/Leadspage/LeadsPage"; // Assuming LeadsPage is here
import ProjectLeadForm from "./pages/ProjectLeadFolder/ProjectLeadForm"; // Assuming ProjectLeadForm is here

// Mock projects data for the VendorDashboard
const mockProjects = [
  {
    id: 1,
    name: "Highway Construction Project",
    client: "National Highway Authority",
    status: "Completed",
    progress: 100,
    budget: "₹15.3 cr",
    startDate: "2023-01-15",
    endDate: "2023-12-20"
  },
  {
    id: 2,
    name: "Railway Electrification",
    client: "Ministry of Railways",
    status: "Pending",
    progress: 65,
    budget: "₹8.7 cr",
    startDate: "2023-05-10",
    endDate: "2024-06-30"
  },
  {
    id: 3,
    name: "Municipal Waste Management",
    client: "Municipal Corporation",
    status: "Completed",
    progress: 100,
    budget: "₹4.2 cr",
    startDate: "2023-03-01",
    endDate: "2023-11-15"
  }
];

const Layout = () => {
  return (
    <div className="bg-[#EEF2F1] min-h-screen "> {/* Or your default page background */}
        <div className="pt-5 px-5 pb-0">
            <Header />
        </div>
 
      <main>
        <Outlet /> {/* Page content will render here */}
      </main>
    </div>
  );
};



function App() {
  return (
    <UserProvider>
      <VendorProvider>
        <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/signup" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/Form1" element={<Form1 />} />
        <Route path="/Form2" element={<Form2 />} />
        <Route path="/Form3" element={<Form3 />} />
        <Route path="/Form4" element={<Form4 />} />
        <Route path="/Form5" element={<Form5 />} />
        <Route path="/Form6" element={<Form6 />} />
        <Route path="/Auditorapprove" element={<Auditor />} />
        <Route path="/NewAuditor" element={<NewAuditorDashboard />} />
        <Route path="/auth/google/callback" element={<GoogleOAuthCallback />} />
        {/* Nested route for VendorDashboard */}
        <Route path="/VendorDashboard" element={<Layout />}>
          <Route index element={<VendorDashboard mockProjects={mockProjects} />} />
          <Route path="projects" element={<ProjectsPage mockProjects={mockProjects} />} />
          <Route path="leads" element={<LeadsPage />} />
        </Route>
        {/* Removed EditCompany route as it's now handled with a modal */}
        <Route path="/home" element={<Home />} />
        <Route path="/userproject" element={<UserProjectPage />} />
        <Route path="/userproduct" element={<UserPortfolio />} />
        <Route path="/pmleads" element={<ProjectLeadForm />} />
        <Route path="/leads/:leadId" element={<LeadDetailPage />} />
        {/* Add other routes as needed */}
      </Routes>
      </VendorProvider>
    </UserProvider>
  );
}

export default App;
